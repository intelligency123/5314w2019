//
//  InterfaceController.swift
//  watchdemo WatchKit Extension
//
//  Created by MacStudent on 2019-02-28.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity


class InterfaceController: WKInterfaceController ,WCSessionDelegate{
   
    
    var labelSaysHello:Bool = true


    @IBOutlet weak var messageLabel: WKInterfaceLabel!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
         print("hello world!")
        if WCSession.isSupported() {
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }

    }
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
       

    }
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        // Play a "click" sound when you get the message
        WKInterfaceDevice().play(.click)
        
        // output a debug message to the terminal
        print("Got a message!")
        
        // update the message with a label
        messageLabel.setText("\(message)")
    }

    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func pushbtn() {
        print("i pushed the button")
        
        if (labelSaysHello == true) {
            messageLabel.setText("GOODBYE")
            self.labelSaysHello = false
        }
        else {
            messageLabel.setText("HELLO")
            self.labelSaysHello = true
        }

    }
}
