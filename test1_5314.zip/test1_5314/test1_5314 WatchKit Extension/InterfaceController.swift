//
//  InterfaceController.swift
//  test1_5314 WatchKit Extension
//
//  Created by MacStudent on 2019-03-04.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity


class InterfaceController: WKInterfaceController, WCSessionDelegate {
    @IBOutlet weak var literlbl: WKInterfaceLabel!
    @IBOutlet weak var costlbl: WKInterfaceLabel!
    var speed = Double()
    var lpk = Double()
    var price = Double()
    var liters = Double()
    var cost = Double()
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        if WCSession.isSupported() {
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }

    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    func session(_ session: WCSession, didReceiveMessage sendliters: [String : Any] ) {
        // Play a "click" sound when you get the message
        WKInterfaceDevice().play(.click)
        
        // output a debug message to the terminal
        print("Got a message!")
        let liters = sendliters["Liters"]
       
        let cost = sendliters["Cost"]
        speed = sendliters["speed"] as! Double
        lpk = sendliters["lpk"] as! Double
        price = sendliters["price"] as! Double
        
        
        // update the message with a label
        literlbl.setText("\( liters ?? "no value")")
        costlbl.setText("\(cost ?? "no value")")
    }
   

    @IBAction func changeValue(_ value: Float) {
         let roundedValue = Double(round(value))
        liters = (roundedValue) * (lpk) * (0.5) * (speed)
        cost = (liters) * (price)
        let l:String = String(liters)
        let m:String = String(cost)
        literlbl.setText(l)
        costlbl.setText(m)
        
        
    }
    
}
