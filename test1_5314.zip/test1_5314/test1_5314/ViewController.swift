//
//  ViewController.swift
//  test1_5314
//
//  Created by MacStudent on 2019-03-04.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit
import WatchConnectivity

class ViewController: UIViewController, WCSessionDelegate{
    @IBOutlet weak var distancelbl: UITextField!
    @IBOutlet weak var speedlbl: UITextField!
    @IBOutlet weak var lpklbl: UITextField!
    @IBOutlet weak var pricelbl: UITextField!
    var liters = Double()
    var cost = Double()
   
    
    
    
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        
    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if (WCSession.isSupported()) {
            print("Yes it is!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        
       
 
        
        

    }

    @IBAction func okbtn(_ sender: UIButton) {
        let dis:Double? = Double(distancelbl.text!)!
        let speed:Double? = Double(speedlbl.text!)!
        let lpk:Double? = Double(lpklbl.text!)!
        let price:Double? = Double(pricelbl.text!)!
        liters = (dis!) * (lpk!) * (0.5) * (speed!)
        cost = (liters) * (price!)
        if (WCSession.default.isReachable) {
            // construct the message you want to send
            // the message is in dictionary
            let sendliters = ["Liters" : liters, "Cost" : cost ,"speed" : speed as Any ,"lpk" : lpk as Any , "price" : price as Any] as [String : Any]
            //let sendcost = ["Cost" : String(cost)]
          
            
            // send the message to the watch
            WCSession.default.sendMessage(sendliters, replyHandler: nil)
             //WCSession.default.sendMessage(sendcost, replyHandler: nil)
           
        }

    }
    
}

